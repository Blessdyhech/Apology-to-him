document.addEventListener('DOMContentLoaded', () => {
    
    const cuteCards = document.querySelectorAll('.card');
    const thePopup = document.getElementById('popup-overlay');
    const popupText = document.getElementById('popup-message');
    const closeBtn = document.querySelector('.close-button');

    
    const sweetMsgs = {
        'card-gentle': `
            <p>I love youu so much for being so gentle with my heart.</p>
            <p>Your kindness is a warm blanket that makes me feel safe. Thank you for being you, my love. You're the best part of my life! </p>
            <p>Big hugs! ❤️</p>
        `,
        'card-safe': `
            <p>Babey, when I'm with you, I feel completely safe and loved.</p>
            <p>I've never love someone like this beforeeee. 
            :(</p>
            <p>I PAKING LOVE YOUU SO MUCH💖</p>
        `,
        'card-home': `
            <p>Babey, you are truly my home.</p>
            <p>It's not a place, but a feeling of comfort and belonging I only get when I talked with you. Home is wherever you are.</p>
            <p>Always and forever! 🏠✨</p>
        `,
        'card-future': `
            <p>Because Babey, I see our future so clearly with you.</p>
            <p>Every dream, every plan, it all includes you. I can't wait to build a wonderful life together and marry you!</p>
            <p>My heart is yours! ♾️</p>
        `
    };

    
    cuteCards.forEach(card => {
        card.addEventListener('click', () => {
            const cardID = card.id;
            if (sweetMsgs[cardID]) {
                popupText.innerHTML = sweetMsgs[cardID];
                thePopup.classList.add('active');
                thePopup.setAttribute('aria-hidden', 'false');
            }
        });
    });

   
    const closePopup = () => {
        thePopup.classList.remove('active');
        thePopup.setAttribute('aria-hidden', 'true');
    };

    
    closeBtn.addEventListener('click', closePopup);
    thePopup.addEventListener('click', (event) => {
        if (event.target === thePopup) {
            closePopup();
        }
    });

    
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && thePopup.classList.contains('active')) {
            closePopup();
        }
    });

    
});